// This is a test harness for your module
// You should do something interesting in this harness 
// to test out the module and to provide instructions 
// to users on how to use it by example.


var hockeyapp = require('nl.rebelic.hockeyapp');
hockeyapp.start('<yourappid>');