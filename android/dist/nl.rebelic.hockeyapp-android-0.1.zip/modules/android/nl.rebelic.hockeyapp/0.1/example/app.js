var hockeyapp = require('nl.rebelic.hockeyapp');
hockeyapp.start('<yourappid>');